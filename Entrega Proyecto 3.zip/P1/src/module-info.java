/**
 * 
 */
/**
 * 
 */
module P1 {
	requires org.junit.jupiter.api;
}