package Proyecto1;

import java.io.Serializable;
import java.util.Scanner;

public class ProfesorCalificador extends Usuario implements Serializable {
	private static Scanner scanner = new Scanner(System.in);
	private int idProfesor;
    public ProfesorCalificador(String nombreUsuario, String contrasena, String correo, int idProfesor) {
    	super(nombreUsuario, contrasena, correo);
        this.idProfesor = idProfesor;
    }

    public void calificarEstudiante(Estudiante estudiante) {
        System.out.println("Revisando actividades del estudiante: " + estudiante.getNombreUsuario());
        for (LearningPath lp : estudiante.getLearningPaths(null)) {
            System.out.println("Learning Path: " + lp.getTitulo());
            for (Actividad actividad : lp.getActividadesCompletadas(estudiante)) {
                System.out.println("Actividad: " + actividad.getNombre());
                System.out.println("Ingrese calificación (1-5): ");
                int calificacion = scanner.nextInt();
                scanner.nextLine(); // limpiar buffer
                System.out.println("¿Fue exitosa? (1 para sí, 0 para no): ");
                boolean exitosa = scanner.nextInt() == 1;
                scanner.nextLine(); // limpiar buffer

                actividad.setCalificacion(calificacion);
                actividad.setExitosa(exitosa);

                System.out.println("Calificación registrada.");
            }
        }
    }

    public void revisarLearningPath(LearningPath lp) {
        int actividadesTotales = lp.getCantidadActividades();
        int actividadesExitosas = lp.getActividadesExitosas();
        double tasaExito = (double) actividadesExitosas / actividadesTotales * 100;

        double horasInvertidas = lp.calcularHorasInvertidas();

        System.out.println("Tasa de éxito del Learning Path: " + tasaExito + "%");
        System.out.println("Horas invertidas: " + horasInvertidas);
    }
    public void revisarLearningPathsEstudiante(Estudiante estudiante) {
        System.out.println("Revisando Learning Paths de: " + estudiante.getNombreUsuario());
        for (LearningPath lp : estudiante.getLearningPaths()) {
            System.out.println("ID: " + lp.getId() + ", Nombre: " + lp.getNombreUsuario());
            System.out.println("Actividades completadas: " + estudiante.getActividadesCompletadas(lp));
        }
    }

    public void calcularEstadisticasLearningPath(LearningPath lp) {
        int totalActividades = lp.getTotalActividades();
        int actividadesExitosas = lp.getActividadesExitosas();
        int horasInvertidas = lp.calcularHorasTotales();

        double tasaExito = (totalActividades > 0) 
            ? (double) actividadesExitosas / totalActividades * 100 
            : 0;

        System.out.println("Estadísticas para el Learning Path: " + lp.getNombreUsuario());
        System.out.println("Tasa de éxito: " + tasaExito + "%");
        System.out.println("Horas totales invertidas: " + horasInvertidas);
    }
    public int getIdProfesor() {
        return idProfesor;
    }

    public void setIdProfesor(int idProfesor) {
        this.idProfesor = idProfesor;
    }
}


