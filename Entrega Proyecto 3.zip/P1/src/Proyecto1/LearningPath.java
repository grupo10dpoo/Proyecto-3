package Proyecto1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


public class LearningPath implements Serializable{
    private int id;
    private String titulo;
    private String descripcion;
    private String tipo; 
    private String objetivo; 
    private String nivelDificultad; 
    private double tiempoEstimado; 
    private List<Actividad> actividades;
    private Reseña ultimaReseña;
    private List<Reseña> resenas;
    
    private List<Estudiante> estudiantesInscritos;

    public LearningPath(int id, String titulo, String descripcion, String tipo, String objetivo, String nivelDificultad, double tiempoEstimado) {
        this.id = id;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.tipo = tipo;
        this.objetivo = objetivo;
        this.nivelDificultad = nivelDificultad;
        this.tiempoEstimado = tiempoEstimado;
        this.actividades = new ArrayList<>();
        this.resenas = new ArrayList<>();
        this.estudiantesInscritos = new ArrayList<>();

    }

    public int getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getObjetivo() {
        return objetivo;
    }

    public void setObjetivo(String objetivo) {
        this.objetivo = objetivo;
    }

    public String getNivelDificultad() {
        return nivelDificultad;
    }

    public void setNivelDificultad(String nivelDificultad) {
        this.nivelDificultad = nivelDificultad;
    }

    public double getTiempoEstimado() {
        return tiempoEstimado;
    }

    public void setTiempoEstimado(double tiempoEstimado) {
        this.tiempoEstimado = tiempoEstimado;
    }

    public List<Actividad> getActividades() {
        return actividades;
    }
    
    public void agregarResena(Reseña resena) {
        resenas.add(resena);
    }
    
    public List<Reseña> getResenas() {
        return resenas;
    }
    
    public void agregarEstudiantesInscritos(Reseña estudiantesInscritos) {
        resenas.add(estudiantesInscritos);
    }
    
    public List<Estudiante> getEstudiantesInscritos() {
     return estudiantesInscritos;
    }
    
    public void agregarActividad(Actividad actividad) {
        actividades.add(actividad);
    }

    public Reseña getUltimaReseña() {
        return ultimaReseña;
    }

    
    public void agregarEstudiante(Estudiante estudiante) {
        this.estudiantesInscritos.add(estudiante);
    }
    
    public void eliminarActividad(int idActividad) {
        actividades.removeIf(actividad -> actividad.getId() == idActividad);
    }

    public double calcularProgreso(Estudiante estudiante) {
        ProgresoEstudiante progreso = estudiante.getProgreso(this.id);
        if (progreso == null) {
            return 0.0;
        }
        long actividadesCompletadas = actividades.stream()
            .filter(actividad -> progreso.getPorcentajeCompletado() > 0)
            .count();
        return (double) actividadesCompletadas / actividades.size() * 100;
    }

    
    public List<Actividad> generarRecomendaciones(Estudiante estudiante) {
        ProgresoEstudiante progreso = estudiante.getProgreso(this.id);
        if (progreso == null) {
            return new ArrayList<>();
        }
        return actividades.stream()
            .filter(actividad -> progreso.getPorcentajeCompletado() == 0)
            .collect(Collectors.toList());
    }
    
    public LearningPath clonar() {
        return new LearningPath(
            this.id,
            this.titulo + " (Copia)",
            this.descripcion,
            this.tipo,
            this.objetivo,
            this.nivelDificultad,
            this.tiempoEstimado
        );
    }
    
    public double calcularTasaDeExito() {
        long actividadesExitosas = actividades.stream()
            .filter(actividad -> "aprobado".equalsIgnoreCase(actividad.getResultado()))
            .count();
        return (double) actividadesExitosas / actividades.size() * 100;
    }
    public int getActividadesExitosas() {
        int exitosas = 0;
        for (Actividad actividad : actividades) {
            if (actividad.isExitosa()) {
                exitosas++;
            }
        }
        return exitosas;
    }

    public double calcularHorasInvertidas() {
        double totalHoras = 0;
        for (Actividad actividad : actividades) {
            totalHoras += actividad.getDuracion();
        }
        return totalHoras;
    }
    public List<Actividad> getActividadesCompletadas(Estudiante estudiante) {
        List<Actividad> completadas = new ArrayList<>();
        for (Actividad actividad : actividades) {
            if (actividad.esCompletadaPor(estudiante)) {
                completadas.add(actividad);
            }
        }
        return completadas;
    }
    public int getCantidadActividades() {
        return actividades.size();
    }
    public List<Actividad> getActividadesCompletadasPorEstudiante(Estudiante estudiante) {
        List<Actividad> completadas = new ArrayList<>();
        for (Actividad actividad : actividades) { // Suponiendo que `actividades` es una lista de todas las actividades.
            if (actividad.esCompletadaPor(estudiante)) { // Método que verifica si la actividad fue completada.
                completadas.add(actividad);
            }
        }
        return completadas;
    }
    public int calcularHorasTotales() {
        int horasTotales = 0;
        for (Actividad actividad : actividades) {
            horasTotales += actividad.getDuracion(); // Supongamos que cada actividad tiene una duración.
        }
        return horasTotales;
    }
    public int getTotalActividades() {
        return actividades.size(); // Suponiendo que `actividades` es una lista que contiene todas las actividades del Learning Path.
    }
    private Estudiante estudiante;

    public String getNombreUsuario() {
        return (estudiante != null) ? estudiante.getNombreUsuario() : "Desconocido";
    }
    public void agregarResena(String nombreEstudiante, String comentario) {
        Reseña nuevaResena = new Reseña(comentario,0, nombreEstudiante);
        resenas.add(nuevaResena);
        ultimaReseña = nuevaResena;
    }
    public boolean marcarActividadCompletada(String nombreActividad, Estudiante estudiante) {
        for (Actividad actividad : actividades) {
            if (actividad.getNombre().equalsIgnoreCase(nombreActividad) && !actividad.isCompletado()) {
                actividad.setCompletado();
                estudiante.completarActividad(this.id, nombreActividad);
                return true;
            }
        }
        return false; // La actividad no se encontró o ya estaba completada
    }


}



