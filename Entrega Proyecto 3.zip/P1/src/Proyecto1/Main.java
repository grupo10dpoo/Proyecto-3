package Proyecto1;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.time.LocalDate;
public class Main implements Serializable{
    public static List<LearningPath> learningPaths = new ArrayList<>();
    public static List<Profesor> profesores = new ArrayList<>();
    public static List<Estudiante> estudiantes = new ArrayList<>();
    public static List<ProfesorCalificador> profesoresCalificador = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);
    private static String directorioBase = ""; 

    public static void main(String[] args) {
        seleccionarDirectorio(); 

        while (true) {
            mostrarMenuPrincipal();
            int opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    crearProfesor();
                    break;
                case 2:
                    crearEstudiante();
                    break;
                case 3:
                	crearProfesorCalificador();
                	break;
                case 4:
                    iniciarSesionProfesor();
                    break;
                case 5:
                    iniciarSesionEstudiante();
                    break;
                case 6:
                	iniciarSesionProfesorCalificador();
                    break;
                case 7:
                    guardarDatos(); 
                    System.out.println("Datos guardados exitosamente.");
                    break;
                case 8:
                    cargarDatos(); 
                    System.out.println("Datos cargados exitosamente.");
                    break;
                case 9:
                    System.out.println("Saliendo...");
                    return;
                default:
                    System.out.println("Opción no válida.");
            }
        }
    }

    private static void seleccionarDirectorio() {
        System.out.println("Por favor, ingresa el directorio donde se guardarán/cargarán los archivos:");
        directorioBase = scanner.nextLine();
        File dir = new File(directorioBase);
        if (!dir.exists()) {
            System.out.println("El directorio no existe, creando...");
            dir.mkdirs(); 
        }
    }


    private static void mostrarMenuPrincipal() {
        System.out.println("\n--- Menú Principal ---");
        System.out.println("1. Crear profesor");
        System.out.println("2. Crear estudiante");
        System.out.println("3. Crear profesor calificador");
        System.out.println("4. Iniciar sesión como profesor");
        System.out.println("5. Iniciar sesión como estudiante");
        System.out.println("6. Iniciar sesión como Profesor Calificador");
        System.out.println("7. Guardar datos");
        System.out.println("8. Cargar datos");
        System.out.println("9. Salir");
        System.out.print("Selecciona una opción: ");
    }

    private static void cargarDatos() {
        cargarProfesores();
        cargarEstudiantes();
        cargarLearningPaths();
        cargarProfesoresCalificadores();
    }

    private static void guardarDatos() {
        guardarProfesores();
        guardarEstudiantes();
        guardarLearningPaths();
        guardarProfesoresCalificadores();
    }
    private static void cargarProfesoresCalificadores() {
        try (BufferedReader br = new BufferedReader(new FileReader(directorioBase + File.separator + "profesorescalificadores.txt"))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(",");
                ProfesorCalificador profesorcalificador = new ProfesorCalificador(datos[0], datos[1], datos[2], Integer.parseInt(datos[3]));
                profesoresCalificador.add(profesorcalificador);
            }
        } catch (IOException e) {
            System.out.println("Error al cargar profesores: " + e.getMessage());
        }
    }
    private static void guardarProfesoresCalificadores() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(directorioBase + File.separator + "profesorescalificadores.txt"))) {
            for (ProfesorCalificador profesorcalificador : profesoresCalificador) {
                pw.println(profesorcalificador.getNombreUsuario() + "," + profesorcalificador.getContrasena() + "," + profesorcalificador.getCorreo() + "," + profesorcalificador.getIdProfesor());
            }
        } catch (IOException e) {
            System.out.println("Error al guardar profesores: " + e.getMessage());
        }
    }
    private static void cargarProfesores() {
        try (BufferedReader br = new BufferedReader(new FileReader(directorioBase + File.separator + "profesores.txt"))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(",");
                Profesor profesor = new Profesor(datos[0], datos[1], datos[2], Integer.parseInt(datos[3]));
                profesores.add(profesor);
            }
        } catch (IOException e) {
            System.out.println("Error al cargar profesores: " + e.getMessage());
        }
    }

    private static void guardarProfesores() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(directorioBase + File.separator + "profesores.txt"))) {
            for (Profesor profesor : profesores) {
                pw.println(profesor.getNombreUsuario() + "," + profesor.getContrasena() + "," + profesor.getCorreo() + "," + profesor.getIdProfesor());
            }
        } catch (IOException e) {
            System.out.println("Error al guardar profesores: " + e.getMessage());
        }
    }

    private static void cargarEstudiantes() {
        try (BufferedReader br = new BufferedReader(new FileReader(directorioBase + File.separator + "estudiantes.txt"))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(",");
                Estudiante estudiante = new Estudiante(datos[0], datos[1], datos[2], Integer.parseInt(datos[3]));
                estudiantes.add(estudiante);
            }
        } catch (IOException e) {
            System.out.println("Error al cargar estudiantes: " + e.getMessage());
        }
    }

    private static void guardarEstudiantes() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(directorioBase + File.separator + "estudiantes.txt"))) {
            for (Estudiante estudiante : estudiantes) {
                pw.println(estudiante.getNombreUsuario() + "," + estudiante.getContrasena() + "," + estudiante.getCorreo() + "," + estudiante.getIdEstudiante());
            }
        } catch (IOException e) {
            System.out.println("Error al guardar estudiantes: " + e.getMessage());
        }
    }

    private static void guardarLearningPaths() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(directorioBase + File.separator + "learningPaths.txt"))) {
            for (LearningPath lp : learningPaths) {
                pw.println(lp.getId() + "," + lp.getTitulo() + "," + lp.getDescripcion() + "," + lp.getTipo() + ","
                    + lp.getObjetivo() + "," + lp.getNivelDificultad() + "," + lp.getTiempoEstimado());
                guardarActividades(lp);
            }
        } catch (IOException e) {
            System.out.println("Error al guardar LearningPaths: " + e.getMessage());
        }
    }

    private static void cargarLearningPaths() {
        try (BufferedReader br = new BufferedReader(new FileReader(directorioBase + File.separator + "learningPaths.txt"))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(",");
                LearningPath lp = new LearningPath(
                    Integer.parseInt(datos[0]), datos[1], datos[2], datos[3], datos[4], datos[5], Double.parseDouble(datos[6])
                );
                learningPaths.add(lp);
                cargarActividades(lp);
            }
        } catch (IOException e) {
            System.out.println("Error al cargar LearningPaths: " + e.getMessage());
        }
    }

    private static void guardarActividades(LearningPath learningPath) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(directorioBase + File.separator + "actividades_" + learningPath.getId() + ".txt"))) {
            for (Actividad actividad : learningPath.getActividades()) {
                pw.println(actividad.getId() + "," + actividad.getNombre() + "," + actividad.getTipo() + "," + actividad.getDescripcion() + ","
                    + actividad.getObjetivo() + "," + actividad.getNivelDificultad() + "," + actividad.getDuracion() + "," + actividad.getFechaEntrega());
            }
        } catch (IOException e) {
            System.out.println("Error al guardar actividades del LearningPath " + learningPath.getId() + ": " + e.getMessage());
        }
    }

    private static void cargarActividades(LearningPath learningPath) {
        try (BufferedReader br = new BufferedReader(new FileReader(directorioBase + File.separator + "actividades_" + learningPath.getId() + ".txt"))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(",");
                Actividad actividad = new Actividad(
                    datos[1], datos[2], Integer.parseInt(datos[0]), datos[3], datos[4], datos[5], 
                    Integer.parseInt(datos[6]), datos[7]
                );
                learningPath.agregarActividad(actividad);
            }
        } catch (IOException e) {
            System.out.println("Error al cargar actividades del LearningPath " + learningPath.getId() + ": " + e.getMessage());
        }
    }

    private static void crearProfesor() {
        System.out.println("Ingrese nombre de usuario:");
        String nombreUsuario = scanner.nextLine();
        System.out.println("Ingrese contraseña:");
        String contrasena = scanner.nextLine();
        System.out.println("Ingrese correo:");
        String correo = scanner.nextLine();

        int id = profesores.size() + 1;
        Profesor profesor = new Profesor(nombreUsuario, contrasena, correo, id);
        profesores.add(profesor);

        System.out.println("Profesor creado exitosamente.");
    }

    private static void crearEstudiante() {
        System.out.println("Ingrese nombre de usuario:");
        String nombreUsuario = scanner.nextLine();
        System.out.println("Ingrese contraseña:");
        String contrasena = scanner.nextLine();
        System.out.println("Ingrese correo:");
        String correo = scanner.nextLine();

        int id = estudiantes.size() + 1;
        Estudiante estudiante = new Estudiante(nombreUsuario, contrasena, correo, id);
        estudiantes.add(estudiante);

        System.out.println("Estudiante creado exitosamente.");
    }

    private static void iniciarSesionProfesor() {
        System.out.println("Ingrese nombre de usuario del profesor:");
        String nombreUsuario = scanner.nextLine();
        System.out.println("Ingrese contraseña:");
        String contrasena = scanner.nextLine();

        Profesor profesor = autenticarProfesor(nombreUsuario, contrasena);
        if (profesor != null) {
            System.out.println("Inicio de sesión exitoso.");
            mostrarMenuProfesor(profesor);
        } else {
            System.out.println("Nombre de usuario o contraseña incorrectos.");
        }
    }

    private static void mostrarMenuProfesor(Profesor profesor) {
        boolean salir = false;
        while (!salir) {
            System.out.println("1. Crear Learning Path");
            System.out.println("2. Modificar Learning Path");
            System.out.println("3. Agregar Actividad");
            System.out.println("4. Ver LearnignPath y Reseña");
            System.out.println("5. Cerrar sesión");
            int opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    crearLearningPathProfesor(profesor);
                    break;
                
                case 2:
                    modificarLearningPath(profesor);
                    break;
                
                case 3:
                    agregarActividad(profesor);
                    break;
                case 4:
                	verLearningPathYReseña();
                case 5:
                    salir = true;
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        }
    }

    private static void crearLearningPathProfesor(Profesor profesor) {
        System.out.println("Ingrese título del Learning Path:");
        String titulo = scanner.nextLine();
        System.out.println("Ingrese descripción:");
        String descripcion = scanner.nextLine();
        System.out.println("Ingrese tipo de Learning Path:");
        String tipo = scanner.nextLine();
        System.out.println("Ingrese el objetivo del Learning Path:");
        String objetivo = scanner.nextLine();
        System.out.println("Ingrese el nivel de dificultad (principiante, intermedio, avanzado):");
        String nivelDificultad = scanner.nextLine();
        System.out.println("Ingrese el tiempo estimado (en horas):");
        double tiempoEstimado = scanner.nextDouble();
        scanner.nextLine(); 

        LearningPath lp = new LearningPath(learningPaths.size() + 1, titulo, descripcion, tipo, objetivo, nivelDificultad, tiempoEstimado);
        profesor.crearLearningPath(lp);
        learningPaths.add(lp);
        System.out.println("Learning Path creado exitosamente.");
    }
    
    private static void modificarLearningPath(Profesor profesor) {
        System.out.println("Ingrese ID del Learning Path a modificar:");
        int idLP = scanner.nextInt();
        scanner.nextLine(); // Limpiar buffer del scanner

        // Buscar el Learning Path en la lista del profesor
        LearningPath lp = null;
        for (LearningPath learningPath : profesor.getLearningPaths()) {
            if (learningPath.getId() == idLP) {
                lp = learningPath;
                break;
            }
        }

        if (lp != null) {
            System.out.println("Ingrese nuevo título:");
            String nuevoTitulo = scanner.nextLine();
            System.out.println("Ingrese nueva descripción:");
            String nuevaDescripcion = scanner.nextLine();
            System.out.println("Ingrese nuevo tipo:");
            String nuevoTipo = scanner.nextLine();
            System.out.println("Ingrese nuevo objetivo:");
            String nuevoObjetivo = scanner.nextLine();
            System.out.println("Ingrese nuevo nivel de dificultad:");
            String nuevoNivelDificultad = scanner.nextLine();
            System.out.println("Ingrese nuevo tiempo estimado (en horas):");
            double nuevoTiempoEstimado = scanner.nextDouble();
            scanner.nextLine(); // Limpiar buffer del scanner

            // Llamar al método de modificarLearningPath
            profesor.modificarLearningPath(
                idLP,
                nuevoTitulo,
                nuevaDescripcion,
                nuevoTipo,
                nuevoObjetivo,
                nuevoNivelDificultad,
                nuevoTiempoEstimado
            );

        } else {
            System.out.println("Learning Path no encontrado.");
        }
    }
    

    private static void agregarActividad(Profesor profesor) {
        System.out.println("Ingrese ID del Learning Path:");
        int idLP = scanner.nextInt();
        scanner.nextLine();
    
        LearningPath lp = obtenerLearningPath(idLP);
        if (lp != null) {
            System.out.println("Ingrese nombre de la actividad:");
            String nombreActividad = scanner.nextLine();
            System.out.println("Ingrese tipo de actividad (Tarea, Examen, etc.):");
            String tipo = scanner.nextLine();
            System.out.println("Ingrese descripción de la actividad:");
            String descripcion = scanner.nextLine();
            System.out.println("Ingrese objetivo de la actividad:");
            String objetivo = scanner.nextLine();
            System.out.println("Ingrese nivel de dificultad de la actividad:");
            String nivelDificultad = scanner.nextLine();
            System.out.println("Ingrese duración de la actividad (en minutos):");
            int duracion = scanner.nextInt();
            System.out.println("Ingrese Fecha de entrega de la actividad:");
            String fechaEntrega = scanner.nextLine();
            scanner.nextLine();  

            int idActividad = lp.getActividades().size() + 1;
    
            Actividad actividad = new Actividad(nombreActividad, tipo, idActividad, descripcion, objetivo, nivelDificultad, duracion,fechaEntrega);
            lp.agregarActividad(actividad);
            System.out.println("Actividad agregada exitosamente.");
        } else {
            System.out.println("Learning Path no encontrado.");
        }
    }


    private static void iniciarSesionEstudiante() {
        System.out.println("Ingrese nombre de usuario del estudiante:");
        String nombreUsuario = scanner.nextLine();
        System.out.println("Ingrese contraseña:");
        String contrasena = scanner.nextLine();

        Estudiante estudiante = autenticarEstudiante(nombreUsuario, contrasena);
        if (estudiante != null) {
            System.out.println("Inicio de sesión exitoso.");
            mostrarMenuEstudiante(estudiante);
        } else {
            System.out.println("Nombre de usuario o contraseña incorrectos.");
        }
    }

    private static void mostrarMenuEstudiante(Estudiante estudiante) {
        boolean salir = false;
        while (!salir) {
            System.out.println("1. Inscribirse en Learning Path");
            System.out.println("2. Marcar Actividad como Finalizada");
            System.out.println("3. Ver Progreso");
            System.out.println("4. Hacer Reseña");
            System.out.println("5. Ver Learning Path y Reseña");
            System.out.println("6. Cerrar sesión");
            int opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    inscribirseEnLearningPath(estudiante);
                    break;
                case 2:
                    completarActividadEstudiante(estudiante);
                    break;
                case 3:
                    verProgreso(estudiante);
                    break;
                case 4:
                    hacerReseñaEstudiante(estudiante);
                    break;
                case 5:
                    verLearningPathYReseña();
                    break;
                case 6:
                    salir = true;
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        }
    }

    private static void inscribirseEnLearningPath(Estudiante estudiante) {
        System.out.println("Ingrese ID del Learning Path:");
        int idLP = scanner.nextInt();
        scanner.nextLine();

        LearningPath lp = obtenerLearningPath(idLP);
        if (lp != null) {
            estudiante.inscribirseEnLearningPath(lp);
        } else {
            System.out.println("Learning Path no encontrado.");
        }
    }

    private static void completarActividadEstudiante(Estudiante estudiante) {
        System.out.println("Ingrese ID del Learning Path:");
        int idLP = scanner.nextInt();
        scanner.nextLine();

        System.out.println("Ingrese nombre de la actividad:");
        String nombreActividad = scanner.nextLine();

        estudiante.completarActividad(idLP, nombreActividad);
    }

    private static void verProgreso(Estudiante estudiante) {
        System.out.println("Ingrese ID del Learning Path:");
        int idLP = scanner.nextInt();
        scanner.nextLine();

        ProgresoEstudiante progreso = estudiante.getProgreso(idLP);
        if (progreso != null) {
            System.out.println("Progreso: " + progreso.getPorcentajeCompletado() + "%");
        } else {
            System.out.println("No se ha iniciado este Learning Path.");
        }
    }

    private static void hacerReseñaEstudiante(Estudiante estudiante) {
        System.out.println("Ingrese ID del Learning Path:");
        int idLP = scanner.nextInt();
        scanner.nextLine();

        LearningPath lp = obtenerLearningPath(idLP);
        if (lp != null) {
            System.out.println("Ingrese su comentario:");
            String comentario = scanner.nextLine();
            System.out.println("Ingrese una calificación (1 a 5):");
            int calificacion = scanner.nextInt();
            scanner.nextLine();

            if (calificacion < 1 || calificacion > 5) {
                System.out.println("La calificación debe estar entre 1 y 5.");
            } else {
                estudiante.hacerReseña(lp, comentario, calificacion);
            }
        } else {
            System.out.println("Learning Path no encontrado.");
        }
    }

    private static void verLearningPathYReseña() {
        System.out.println("Ingrese ID del Learning Path:");
        int idLP = scanner.nextInt();
        scanner.nextLine();

        LearningPath lp = obtenerLearningPath(idLP);
        if (lp != null) {
            System.out.println("Learning Path: " + lp.getTitulo());
            System.out.println("Descripción: " + lp.getDescripcion());
            System.out.println("Tipo: " + lp.getTipo());
            System.out.println("Objetivo: " + lp.getObjetivo());
            System.out.println("Nivel de dificultad: " + lp.getNivelDificultad());
            System.out.println("Tiempo estimado(Horas): " + lp.getTiempoEstimado());
            Reseña ultimaReseña = lp.getUltimaReseña();
            if (ultimaReseña != null) {
                System.out.println("Última reseña: " + ultimaReseña);
            } else {
                System.out.println("Este Learning Path aún no tiene reseñas.");
            }
        } else {
            System.out.println("Learning Path no encontrado.");
        }
    }

    private static Profesor obtenerProfesor(int id) {
        for (Profesor p : profesores) {
            if (p.getIdProfesor() == id) {
                return p;
            }
        }
        return null;
    }

    private static Estudiante obtenerEstudiante(int id) {
        for (Estudiante e : estudiantes) {
            if (e.getIdEstudiante() == id) {
                return e;
            }
        }
        return null;
    }

    private static LearningPath obtenerLearningPath(int id) {
        for (LearningPath lp : learningPaths) {
            if (lp.getId() == id) {
                return lp;
            }
        }
        return null;
    }

private static Profesor autenticarProfesor(String nombreUsuario, String contrasena) {
    for (Profesor profesor : profesores) {
        if (profesor.getNombreUsuario().equals(nombreUsuario) && profesor.getContrasena().equals(contrasena)) {
            return profesor;
        }
    }
    return null; // No se encontró el profesor
}

private static Estudiante autenticarEstudiante(String nombreUsuario, String contrasena) {
    for (Estudiante estudiante : estudiantes) {
        if (estudiante.getNombreUsuario().equals(nombreUsuario) && estudiante.getContrasena().equals(contrasena)) {
            return estudiante;
        }
    }
    return null; // No se encontró el estudiante
}
private static ProfesorCalificador autenticarProfesorCalificador(String nombreUsuario, String contrasena) {
    for (ProfesorCalificador profesorCalificador : profesoresCalificador) {
        if (profesorCalificador.getNombreUsuario().equals(nombreUsuario) && profesorCalificador.getContrasena().equals(contrasena)) {
            return profesorCalificador;
        }
    }
    return null; // No se encontró el profesor
}
private static void crearProfesorCalificador() {
    System.out.println("Ingrese nombre de usuario:");
    String nombreUsuario = scanner.nextLine();
    System.out.println("Ingrese contraseña:");
    String contrasena = scanner.nextLine();
    System.out.println("Ingrese correo:");
    String correo = scanner.nextLine();

    int id = profesores.size() + 1;
    ProfesorCalificador profesor = new ProfesorCalificador(nombreUsuario, contrasena, correo, id);
    profesoresCalificador.add(profesor);

    System.out.println("Profesor creado exitosamente.");
}
private static void iniciarSesionProfesorCalificador() {
    System.out.println("Ingrese nombre de usuario del Profesor Calificador:");
    String nombreUsuario = scanner.nextLine();
    System.out.println("Ingrese contraseña:");
    String contrasena = scanner.nextLine();

    ProfesorCalificador profesorCalificador = autenticarProfesorCalificador(nombreUsuario, contrasena);
    if (profesorCalificador != null) {
        System.out.println("Inicio de sesión exitoso.");
        mostrarMenuProfesorCalificador(profesorCalificador);
    } else {
        System.out.println("Nombre de usuario o contraseña incorrectos.");
    }
}

private static void mostrarMenuProfesorCalificador(ProfesorCalificador profesorCalificador) {
    boolean salir = false;
    while (!salir) {
        System.out.println("\n--- Menú Profesor Calificador ---");
        System.out.println("1. Revisar Learning Paths de un Estudiante");
        System.out.println("2. Revisar un Learning Path Específico");
        System.out.println("3. Calcular estadísticas de un Learning Path");
        System.out.println("4. Cerrar sesión");
        System.out.print("Selecciona una opción: ");
        int opcion = scanner.nextInt();
        scanner.nextLine(); // Limpiar buffer

        switch (opcion) {
            case 1:
                revisarLearningPathsEstudiante(profesorCalificador);
                break;
            case 2:
                revisarLearningPathEspecifico(profesorCalificador);
                break;
            case 3:
                calcularEstadisticasLearningPath(profesorCalificador);
                break;
            case 4:
                salir = true;
                break;
            default:
                System.out.println("Opción no válida.");
        }
    }
}

private static void revisarLearningPathsEstudiante(ProfesorCalificador profesorCalificador) {
    System.out.println("Ingrese el ID del estudiante:");
    int idEstudiante = scanner.nextInt();
    scanner.nextLine(); // Limpiar buffer
    Estudiante estudiante = obtenerEstudiantePorId(idEstudiante);

    if (estudiante != null) {
        profesorCalificador.revisarLearningPathsEstudiante(estudiante);
    } else {
        System.out.println("Estudiante no encontrado.");
    }
}

private static void revisarLearningPathEspecifico(ProfesorCalificador profesorCalificador) {
    System.out.println("Ingrese el ID del Learning Path:");
    int idLP = scanner.nextInt();
    scanner.nextLine(); // Limpiar buffer
    LearningPath lp = obtenerLearningPath(idLP);

    if (lp != null) {
        profesorCalificador.revisarLearningPath(lp);
    } else {
        System.out.println("Learning Path no encontrado.");
    }
}

private static void calcularEstadisticasLearningPath(ProfesorCalificador profesorCalificador) {
    System.out.println("Ingrese el ID del Learning Path:");
    int idLP = scanner.nextInt();
    scanner.nextLine(); // Limpiar buffer
    LearningPath lp = obtenerLearningPath(idLP);

    if (lp != null) {
        profesorCalificador.calcularEstadisticasLearningPath(lp);
    } else {
        System.out.println("Learning Path no encontrado.");
    }
}
private static Estudiante obtenerEstudiantePorId(int idEstudiante) {
    for (Estudiante estudiante : estudiantes) {
        if (estudiante.getIdEstudiante() == idEstudiante) {
            return estudiante;
        }
    }
    return null; // Si no se encuentra
}
public static Profesor buscarProfesor(String nombre, String contrasena) {
    for (Profesor profesor : profesores) {
        if (profesor.getNombreUsuario().equals(nombre) && profesor.getContrasena().equals(contrasena)) {
            return profesor;
        }
    }
    return null; // No se encontró
}
public static Estudiante buscarEstudiante(String nombre, String contrasena) {
    for (Estudiante estudiante : estudiantes) {
        if (estudiante.getNombreUsuario().equals(nombre) && estudiante.getContrasena().equals(contrasena)) {
            return estudiante;
        }
    }
    return null;
}

public static ProfesorCalificador buscarProfesorCalificador(String nombre, String contrasena) {
    for (ProfesorCalificador profesorCalificador : profesoresCalificador) {
        if (profesorCalificador.getNombreUsuario().equals(nombre) && profesorCalificador.getContrasena().equals(contrasena)) {
            return profesorCalificador;
        }
    }
    return null;
}
public static LearningPath getLearningPathById(int id) {
    for (LearningPath learningPath : learningPaths) {
        if (learningPath.getId() == id) {
            return learningPath;
        }
    }
    return null; // Si no se encuentra el Learning Path
}
public static void agregarLearningPath(LearningPath lp) {
    learningPaths.add(lp);
}
}
