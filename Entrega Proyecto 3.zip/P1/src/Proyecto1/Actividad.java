package Proyecto1;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
public class Actividad implements Serializable{
    private String nombre;
    private String tipo; 
    private boolean completada;
    private int id;
    private double rating;
    private String descripcion;
    private String objetivo;
    private String nivelDificultad;
    private String resultado;
    private int duracion;
    private List<Integer> notas;
    private Map<Integer, String> resultadosEstudiantes;
    private int calificacion;
    private boolean exitosa;
    private List<Estudiante> estudiantesCompletaron;
    private String fechaEntrega;
    private String retroalimentacion;
    
    public Actividad(String nombre, String tipo, int id, String descripcion, String objetivo, String nivelDificultad, int duracion,String fechaEntrega2) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.completada = false;
        this.id = id;
        this.rating = 0.0;
        this.descripcion = descripcion;
        this.objetivo = objetivo;
        this.nivelDificultad = nivelDificultad;
        this.resultado = "pendiente";
        this.duracion = duracion;
        this.resultadosEstudiantes = new HashMap<>();
        this.fechaEntrega = fechaEntrega2;
        this.estudiantesCompletaron = new ArrayList<>();
        this.notas = new ArrayList<>();
        this.retroalimentacion = "";
        
    }

    public String getNombre() {
        return nombre;
    }

    public String getTipo() {
        return tipo;
    }
    public List<Integer> getNotas() {
        return notas;
    }
    public String getRetroalimentacion() {
        return retroalimentacion;
    }

    public boolean isCompletado() {
        return completada;
    }

    public void setCompletado() {
        this.completada = true;
    }
    public int getId() {
        return id;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getObjetivo() {
        return objetivo;
    }

    public void setObjetivo(String objetivo) {
        this.objetivo = objetivo;
    }

    public String getNivelDificultad() {
        return nivelDificultad;
    }

    public void setNivelDificultad(String nivelDificultad) {
        this.nivelDificultad = nivelDificultad;
    }

    public String getResultado() {
        return resultado;
    }

    public void setResultado(String resultado) {
        this.resultado = resultado;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }
    public void asignarAEstudiante(int idEstudiante) {
        resultadosEstudiantes.put(idEstudiante, ""); 
    }

    public void calificarActividad(int idEstudiante, String resultado) {
        if (resultadosEstudiantes.containsKey(idEstudiante)) {
            resultadosEstudiantes.put(idEstudiante, resultado);
            System.out.println("Actividad calificada para el estudiante con ID " + idEstudiante);
        } else {
            System.out.println("Estudiante no encontrado en esta actividad.");
        }
    }

    public String obtenerResultado(int idEstudiante) {
        return resultadosEstudiantes.getOrDefault(idEstudiante, "No asignado o no calificado");
    }
    
    public void calificar(double calificacion) {
        if (calificacion >= 3.0) {
            this.resultado = "aprobado";
        } else {
            this.resultado = "reprobado";
        }
    }
    public void setCalificacion(int calificacion) {
        this.calificacion = calificacion;
    }

    public void setExitosa(boolean exitosa) {
        this.exitosa = exitosa;
    }
    public boolean esCompletadaPor(Estudiante estudiante) {
        return estudiantesCompletaron.contains(estudiante);
    }
    public boolean isExitosa() {
        return exitosa;
    }
    public String getFechaEntrega() {
        return fechaEntrega;
    }

    public void setFechaEntrega(String fechaEntrega) {
        this.fechaEntrega = fechaEntrega;
    }
    public void completarPorEstudiante(Estudiante estudiante) {
        if (!estudiantesCompletaron.contains(estudiante)) {
            estudiantesCompletaron.add(estudiante);
        }
    }

    public void agregarEstudianteCompleto(Estudiante estudiante) {
        if (!estudiantesCompletaron.contains(estudiante)) {
            estudiantesCompletaron.add(estudiante);
        }
    }
    public List<Estudiante> getEstudiantesCompletaron() {
        return estudiantesCompletaron;
    }
    public void calificar(int nota, String retroalimentacion) {
        if (nota < 1 || nota > 5) {
            throw new IllegalArgumentException("La nota debe estar entre 1 y 5.");
        }
        notas.add(nota);
        System.out.println("Actividad calificada con nota: " + nota + " y retroalimentación: " + retroalimentacion);
    }
    

}
    
   


