package Proyecto1.GUI;

import javax.swing.*;

import Proyecto1.LearningPath;

import java.awt.*;
import java.util.List;

public class VerLearningPathsGUI extends JFrame {
    public VerLearningPathsGUI(List<LearningPath> learningPaths) {
        setTitle("Lista de Learning Paths");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        DefaultListModel<String> listModel = new DefaultListModel<>();
        for (LearningPath lp : learningPaths) {
            listModel.addElement("Titulo: "+lp.getTitulo() + " | ID: " + lp.getId()+" | Descripcion: "+lp.getDescripcion()+" | Tipo: "+lp.getTipo()+" | Objetivo: "+lp.getObjetivo()+" | Dificultad: "+lp.getNivelDificultad()+" | Tiempo Estimado: "+lp.getTiempoEstimado()+ " | ");
        }

        JList<String> list = new JList<>(listModel);
        panel.add(new JScrollPane(list), BorderLayout.CENTER);

        add(panel);
    }
}
