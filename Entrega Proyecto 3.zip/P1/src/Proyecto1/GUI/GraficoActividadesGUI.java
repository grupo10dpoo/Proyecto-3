package Proyecto1.GUI;

import javax.swing.*;
import java.awt.*;
import java.util.Map;

public class GraficoActividadesGUI extends JFrame {
    public GraficoActividadesGUI(Map<String, Long> actividadesPorFecha) {
        setTitle("Gráfico de Actividades");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        HeatMapPanel heatMapPanel = new HeatMapPanel(actividadesPorFecha);
        add(heatMapPanel);
    }

    private static class HeatMapPanel extends JPanel {
        private Map<String, Long> actividadesPorFecha;

        public HeatMapPanel(Map<String, Long> actividadesPorFecha) {
            this.actividadesPorFecha = actividadesPorFecha;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;

            int cellSize = 20; // Tamaño de cada celda
            int padding = 5;   // Espacio entre celdas
            int startX = 50;   // Posición inicial en X
            int startY = 50;   // Posición inicial en Y

            int x = startX;
            int y = startY;

            // Dibujar las celdas del mapa de calor
            for (Map.Entry<String, Long> entry : actividadesPorFecha.entrySet()) {
                long count = entry.getValue();
                Color color = calcularColor(count); // Determina el color según el número de actividades

                g2d.setColor(color);
                g2d.fillRect(x, y, cellSize, cellSize); // Dibuja la celda
                g2d.setColor(Color.BLACK);
                g2d.drawRect(x, y, cellSize, cellSize); // Bordes

                // Avanza a la siguiente celda
                x += cellSize + padding;
                if (x + cellSize > getWidth()) { // Si alcanza el final de la fila
                    x = startX;
                    y += cellSize + padding; // Baja a la siguiente fila
                }
            }
        }

        private Color calcularColor(long count) {
            // Escala de colores: cuanto mayor sea el número de actividades, más oscuro el color verde
            int intensity = (int) Math.min(255, count * 30); // Escalar la intensidad
            return new Color(0, intensity, 0); // Verde con intensidad basada en el valor
        }
    }
}
