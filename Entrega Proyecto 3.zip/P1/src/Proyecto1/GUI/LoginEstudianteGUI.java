package Proyecto1.GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import Proyecto1.Estudiante; // Clase lógica
import Proyecto1.LearningPath;
import Proyecto1.Main; // Acceso a datos compartidos
import Proyecto1.Profesor;

public class LoginEstudianteGUI extends JFrame {
    public LoginEstudianteGUI(List<Estudiante> estudiantes, List<LearningPath> learningPaths) {
        setTitle("Inicio de Sesión - Estudiante");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 2, 10, 10));

        // Campos de credenciales
        JTextField nombreField = new JTextField();
        JPasswordField contrasenaField = new JPasswordField();

        // Botón para iniciar sesión
        JButton loginBtn = new JButton("Iniciar Sesión");
        loginBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombre = nombreField.getText();
                String contrasena = new String(contrasenaField.getPassword());

                // Validación de credenciales
                Estudiante estudiante = Main.buscarEstudiante(nombre, contrasena);
                if (estudiante != null) {
                    JOptionPane.showMessageDialog(null, "Inicio de sesión exitoso.");
                    new MenuEstudianteGUI(estudiante,learningPaths).setVisible(true);
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Credenciales incorrectas.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Añadir componentes al panel
        panel.add(new JLabel("Nombre de Usuario:"));
        panel.add(nombreField);
        panel.add(new JLabel("Contraseña:"));
        panel.add(contrasenaField);
        panel.add(new JLabel());
        panel.add(loginBtn);

        add(panel);
    }
}

