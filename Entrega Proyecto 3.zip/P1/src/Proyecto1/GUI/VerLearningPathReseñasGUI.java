package Proyecto1.GUI;

import javax.swing.*;
import java.awt.*;
import Proyecto1.LearningPath;
import Proyecto1.Main;

public class VerLearningPathReseñasGUI extends JFrame {
    public VerLearningPathReseñasGUI() {
        setTitle("Ver Learning Path y Reseñas");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout());

        // Crear una lista con los Learning Paths
        JList<LearningPath> lpList = new JList<>(Main.learningPaths.toArray(new LearningPath[0]));
        JTextArea detallesArea = new JTextArea();
        detallesArea.setEditable(false);

        // Agregar un listener para mostrar detalles al seleccionar un Learning Path
        lpList.addListSelectionListener(e -> {
            LearningPath lpSeleccionado = lpList.getSelectedValue();
            if (lpSeleccionado != null) {
                detallesArea.setText("Título: " + lpSeleccionado.getTitulo() + "\n" +
                                     "Descripción: " + lpSeleccionado.getDescripcion() + "\n" +
                                     "Número de actividades: " + lpSeleccionado.getActividades().size());
            }
        });

        panel.add(new JScrollPane(lpList), BorderLayout.WEST);
        panel.add(new JScrollPane(detallesArea), BorderLayout.CENTER);

        add(panel);
    }
}


