package Proyecto1.GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import Proyecto1.Estudiante; // Clase lógica
import Proyecto1.Main; // Acceso a datos compartidos

public class CrearEstudianteGUI extends JFrame {
    public CrearEstudianteGUI() {
        setTitle("Crear Estudiante");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 2, 10, 10));

        // Campos de entrada
        JTextField nombreField = new JTextField();
        JPasswordField contrasenaField = new JPasswordField();
        JTextField correoField = new JTextField();

        // Botón de registro
        JButton crearBtn = new JButton("Crear Estudiante");
        crearBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombre = nombreField.getText();
                String contrasena = new String(contrasenaField.getPassword());
                String correo = correoField.getText();

                if (nombre.isEmpty() || contrasena.isEmpty() || correo.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Por favor, completa todos los campos.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Crear el estudiante y añadirlo a la lista
                Estudiante estudiante = new Estudiante(nombre, contrasena, correo, Main.estudiantes.size()+1);
                Main.estudiantes.add(estudiante);
                JOptionPane.showMessageDialog(null, "Estudiante creado exitosamente.");
                dispose();
            }
        });

        // Añadir componentes al panel
        panel.add(new JLabel("Nombre de Usuario:"));
        panel.add(nombreField);
        panel.add(new JLabel("Contraseña:"));
        panel.add(contrasenaField);
        panel.add(new JLabel("Correo:"));
        panel.add(correoField);
        panel.add(new JLabel());
        panel.add(crearBtn);

        add(panel);
    }
}

