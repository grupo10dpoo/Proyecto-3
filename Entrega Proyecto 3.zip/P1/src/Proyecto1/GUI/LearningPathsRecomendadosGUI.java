package Proyecto1.GUI;

import Proyecto1.Estudiante;
import Proyecto1.LearningPath;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.stream.Collectors;

public class LearningPathsRecomendadosGUI extends JFrame {
    public LearningPathsRecomendadosGUI(Estudiante estudiante, List<LearningPath> learningPaths) {
        setTitle("Learning Paths Recomendados");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout());

        DefaultListModel<String> listModel = new DefaultListModel<>();
        List<LearningPath> recomendados = learningPaths.stream()
                .filter(lp -> !estudiante.getLearningPathsInscritos().contains(lp))
                .collect(Collectors.toList());

        for (LearningPath lp : recomendados) {
            listModel.addElement("Titulo: "+lp.getTitulo() + " | ID: " + lp.getId()+" | Descripcion: "+lp.getDescripcion()+" | Tipo: "+lp.getTipo()+" | Objetivo: "+lp.getObjetivo()+" | Dificultad: "+lp.getNivelDificultad()+" | Tiempo Estimado: "+lp.getTiempoEstimado()+ " | ");
        }

        JList<String> lpList = new JList<>(listModel);
        panel.add(new JScrollPane(lpList), BorderLayout.CENTER);

        add(panel);
    }
}

