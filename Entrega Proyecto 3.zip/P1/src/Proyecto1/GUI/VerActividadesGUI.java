package Proyecto1.GUI;

import Proyecto1.Estudiante;
import Proyecto1.LearningPath;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class VerActividadesGUI extends JFrame {
    public VerActividadesGUI(Estudiante estudiante, List<LearningPath> learningPaths) {
        setTitle("Ver y Completar Actividades");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout());

        JComboBox<LearningPath> lpComboBox = new JComboBox<>(learningPaths.toArray(new LearningPath[0]));
        JTextArea actividadesArea = new JTextArea(10, 30);

        JButton completarBtn = new JButton("Marcar como Completada");
        completarBtn.addActionListener(e -> {
            LearningPath selectedLP = (LearningPath) lpComboBox.getSelectedItem();
            if (selectedLP != null) {
                String actividadNombre = JOptionPane.showInputDialog("Ingrese el nombre de la actividad completada:");
                boolean completada = selectedLP.marcarActividadCompletada(actividadNombre, estudiante);
                if (completada) {
                    JOptionPane.showMessageDialog(this, "Actividad marcada como completada.");
                } else {
                    JOptionPane.showMessageDialog(this, "Actividad no encontrada o ya completada.");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Por favor selecciona un Learning Path.");
            }
        });

        panel.add(lpComboBox, BorderLayout.NORTH);
        panel.add(new JScrollPane(actividadesArea), BorderLayout.CENTER);
        panel.add(completarBtn, BorderLayout.SOUTH);

        add(panel);
    }
}

