package Proyecto1.GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import Proyecto1.LearningPath;
import Proyecto1.Profesor;
import Proyecto1.Actividad;
import Proyecto1.Estudiante;
import Proyecto1.ProfesorCalificador;

public class MenuPrincipalGUI extends JFrame {
    private List<Actividad> actividades;
    private List<Profesor> profesores;
    private List<LearningPath> learningPaths;
    private List<Estudiante> estudiantes;
    private List<ProfesorCalificador> profesoresCalificador;

    public MenuPrincipalGUI(List<Profesor> profesores, List<LearningPath> learningPaths,
                            List<Actividad> actividades, List<Estudiante> estudiantes,
                            List<ProfesorCalificador> profesoresCalificador) {
        this.profesores = profesores;
        this.learningPaths = learningPaths;
        this.actividades = actividades;
        this.estudiantes = estudiantes;
        this.profesoresCalificador = profesoresCalificador;

        setTitle("Menú Principal");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(10, 1, 10, 10)); // 10 botones

        // Botón para "Crear Profesor"
        JButton crearProfesorBtn = new JButton("Crear Profesor");
        crearProfesorBtn.addActionListener(e -> new CrearProfesorGUI().setVisible(true));

        // Botón para "Crear Estudiante"
        JButton crearEstudianteBtn = new JButton("Crear Estudiante");
        crearEstudianteBtn.addActionListener(e -> new CrearEstudianteGUI().setVisible(true));

        // Botón para "Crear Profesor Calificador"
        JButton crearProfesorCalificadorBtn = new JButton("Crear Profesor Calificador");
        crearProfesorCalificadorBtn.addActionListener(e -> new CrearProfesorCalificadorGUI().setVisible(true));

        // Botón para "Iniciar sesión como Profesor"
        JButton iniciarSesionProfesorBtn = new JButton("Iniciar sesión como Profesor");
        iniciarSesionProfesorBtn.addActionListener(e -> new LoginProfesorGUI(profesores, learningPaths).setVisible(true));

        // Botón para "Iniciar sesión como Estudiante"
        JButton iniciarSesionEstudianteBtn = new JButton("Iniciar sesión como Estudiante");
        iniciarSesionEstudianteBtn.addActionListener(e -> new LoginEstudianteGUI(estudiantes, learningPaths).setVisible(true));

        // Botón para "Iniciar sesión como Profesor Calificador"
        JButton iniciarSesionProfesorCalificadorBtn = new JButton("Iniciar sesión como Profesor Calificador");
        iniciarSesionProfesorCalificadorBtn.addActionListener(e -> new LoginProfesorCalificadorGUI(profesoresCalificador, actividades).setVisible(true));

        // Botón para "Guardar datos"
     // Botón para "Guardar datos"
        JButton guardarDatosBtn = new JButton("Guardar datos");
        guardarDatosBtn.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Guardar datos");
            fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY); // Solo archivos
            int userSelection = fileChooser.showSaveDialog(null);
            
            if (userSelection == JFileChooser.APPROVE_OPTION) {
                File fileToSave = fileChooser.getSelectedFile();
                guardarDatos(fileToSave.getAbsolutePath());
            }
        });


     // Botón para "Cargar datos"
        JButton cargarDatosBtn = new JButton("Cargar datos");
        cargarDatosBtn.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Cargar datos");
            fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY); // Solo archivos
            int userSelection = fileChooser.showOpenDialog(null);
            
            if (userSelection == JFileChooser.APPROVE_OPTION) {
                File fileToLoad = fileChooser.getSelectedFile();
                cargarDatos(fileToLoad.getAbsolutePath());
            }
        });


        // Botón para "Ver Gráfico de Actividades"
        JButton verGraficoBtn = new JButton("Ver Gráfico de Actividades");
        verGraficoBtn.addActionListener(e -> mostrarGrafico());

        // Botón para "Salir"
        JButton salirBtn = new JButton("Salir");
        salirBtn.addActionListener(e -> System.exit(0));

        // Añadir botones al panel
        panel.add(crearProfesorBtn);
        panel.add(crearEstudianteBtn);
        panel.add(crearProfesorCalificadorBtn);
        panel.add(iniciarSesionProfesorBtn);
        panel.add(iniciarSesionEstudianteBtn);
        panel.add(iniciarSesionProfesorCalificadorBtn);
        panel.add(guardarDatosBtn);
        panel.add(cargarDatosBtn);
        panel.add(verGraficoBtn);
        panel.add(salirBtn);

        add(panel);
    }

    private void mostrarGrafico() {
        if (actividades.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No hay actividades para mostrar.");
            return;
        }

        Map<String, Long> actividadesPorFecha = actividades.stream()
                .collect(Collectors.groupingBy(Actividad::getFechaEntrega, Collectors.counting()));

        new GraficoActividadesGUI(actividadesPorFecha).setVisible(true);
    }

    private void guardarDatos(String rutaArchivo) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(rutaArchivo))) {
            oos.writeObject(profesores);
            oos.writeObject(estudiantes);
            oos.writeObject(learningPaths);
            oos.writeObject(actividades);
            oos.writeObject(profesoresCalificador);
            JOptionPane.showMessageDialog(this, "Datos guardados exitosamente en " + rutaArchivo);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error al guardar los datos: " + e.getMessage());
        }
    }


    private void cargarDatos(String rutaArchivo) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(rutaArchivo))) {
            profesores = (List<Profesor>) ois.readObject();
            estudiantes = (List<Estudiante>) ois.readObject();
            learningPaths = (List<LearningPath>) ois.readObject();
            actividades = (List<Actividad>) ois.readObject();
            profesoresCalificador = (List<ProfesorCalificador>) ois.readObject();
            JOptionPane.showMessageDialog(this, "Datos cargados exitosamente desde " + rutaArchivo);
        } catch (IOException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar los datos: " + e.getMessage());
        }
    }


    public static void main(String[] args) {
        List<Profesor> profesores = new ArrayList<>();
        List<LearningPath> learningPaths = new ArrayList<>();
        List<Actividad> actividades = new ArrayList<>();
        List<Estudiante> estudiantes = new ArrayList<>();
        List<ProfesorCalificador> profesoresCalificador = new ArrayList<>();

        SwingUtilities.invokeLater(() -> {
            MenuPrincipalGUI menu = new MenuPrincipalGUI(profesores, learningPaths, actividades, estudiantes, profesoresCalificador);
            menu.setVisible(true);
        });
    }
  
}
