package Proyecto1.GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;
import Proyecto1.Actividad;
import Proyecto1.ProfesorCalificador;

public class MenuProfesorCalificadorGUI extends JFrame {

    private List<Actividad> actividadesCompletadas;

    public MenuProfesorCalificadorGUI(ProfesorCalificador profesorCalificador, List<Actividad> actividades) {
    	this.actividadesCompletadas= actividades;
        setTitle("Menú del Profesor Calificador");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 1, 10, 10));

        JLabel welcomeLabel = new JLabel("Bienvenido, " + profesorCalificador.getNombreUsuario(), SwingConstants.CENTER);
        panel.add(welcomeLabel);

        JButton calificarEstudiantesBtn = new JButton("Calificar Estudiantes");
        calificarEstudiantesBtn.addActionListener(e -> new CalificarActividadGUI(profesorCalificador, actividades));

        JButton tasaExitoBtn = new JButton("Revisar Tasa de Éxito y Tiempo");
        tasaExitoBtn.addActionListener(e -> new TasaExitoGUI(actividades));

        JButton cerrarSesionBtn = new JButton("Cerrar Sesión");
        cerrarSesionBtn.addActionListener(e -> dispose());

        panel.add(calificarEstudiantesBtn);
        panel.add(tasaExitoBtn);
        panel.add(cerrarSesionBtn);

        add(panel);
    }

    private void abrirCalificarActividadesGUI() {
        JFrame calificarFrame = new JFrame("Calificar Actividades");
        calificarFrame.setSize(600, 400);
        calificarFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        calificarFrame.setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout());

        // Lista de actividades completadas
        DefaultListModel<String> modelo = new DefaultListModel<>();
        for (Actividad actividad : actividadesCompletadas) {
            modelo.addElement(actividad.getNombre());
        }
        JList<String> listaActividades = new JList<>(modelo);
        JScrollPane scrollPane = new JScrollPane(listaActividades);

        // Panel inferior para calificar
        JPanel panelInferior = new JPanel(new GridLayout(3, 2, 10, 10));
        JTextField notaField = new JTextField();
        JTextArea retroalimentacionArea = new JTextArea(3, 20);

        panelInferior.add(new JLabel("Nota (1-5):"));
        panelInferior.add(notaField);
        panelInferior.add(new JLabel("Retroalimentación:"));
        panelInferior.add(new JScrollPane(retroalimentacionArea));

        JButton calificarBtn = new JButton("Calificar");
        calificarBtn.addActionListener(e -> {
            String actividadSeleccionada = listaActividades.getSelectedValue();
            if (actividadSeleccionada == null) {
                JOptionPane.showMessageDialog(calificarFrame, "Seleccione una actividad para calificar.");
                return;
            }
            try {
                int nota = Integer.parseInt(notaField.getText());
                if (nota < 1 || nota > 5) {
                    JOptionPane.showMessageDialog(calificarFrame, "La nota debe estar entre 1 y 5.");
                    return;
                }
                for (Actividad actividad : actividadesCompletadas) {
                    if (actividad.getNombre().equals(actividadSeleccionada)) {
                        actividad.calificar(nota, retroalimentacionArea.getText());
                        JOptionPane.showMessageDialog(calificarFrame, "Actividad calificada exitosamente.");
                        break;
                    }
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(calificarFrame, "Ingrese un número válido para la nota.");
            }
        });

        panelInferior.add(new JLabel()); // Espacio vacío
        panelInferior.add(calificarBtn);

        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(panelInferior, BorderLayout.SOUTH);

        calificarFrame.add(panel);
        calificarFrame.setVisible(true);
    }

    private void mostrarEstadisticas() {
        int actividadesExitosas = 0;
        double tiempoTotal = 0;
        int totalCalificadas = 0;

        for (Actividad actividad : actividadesCompletadas) {
            // Contar si la actividad es exitosa (tiene alguna nota >= 3)
            for (int nota : actividad.getNotas()) {
                if (nota >= 3) {
                    actividadesExitosas++;
                    break; // Una vez que sabemos que es exitosa, salimos del loop
                }
            }

            // Sumar el tiempo estimado de la actividad
            tiempoTotal += actividad.getDuracion();

            // Contar actividades calificadas
            if (!actividad.getNotas().isEmpty()) {
                totalCalificadas++;
            }
        }

        // Calcular y mostrar estadísticas
        double promedioTiempo = totalCalificadas > 0 ? tiempoTotal / totalCalificadas : 0;

        JOptionPane.showMessageDialog(
            this,
            "Estadísticas de actividades:\n" +
            "Actividades exitosas: " + actividadesExitosas + "\n" +
            "Tiempo promedio dedicado: " + promedioTiempo + " horas"
        );
    }    
    }

