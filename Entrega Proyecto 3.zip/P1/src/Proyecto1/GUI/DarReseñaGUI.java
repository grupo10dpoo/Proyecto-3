package Proyecto1.GUI;

import Proyecto1.Estudiante;
import Proyecto1.LearningPath;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class DarReseñaGUI extends JFrame {
    public DarReseñaGUI(Estudiante estudiante, List<LearningPath> learningPaths) {
        setTitle("Dar Reseña sobre un Learning Path");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout());

        JComboBox<LearningPath> lpComboBox = new JComboBox<>(learningPaths.toArray(new LearningPath[0]));
        JTextArea reseñaArea = new JTextArea(5, 20);

        JButton darReseñaBtn = new JButton("Agregar Reseña");
        darReseñaBtn.addActionListener(e -> {
            LearningPath selectedLP = (LearningPath) lpComboBox.getSelectedItem();
            String reseña = reseñaArea.getText();

            if (selectedLP != null && !reseña.isEmpty()) {
                selectedLP.agregarResena(estudiante.getNombreUsuario(), reseña);
                JOptionPane.showMessageDialog(this, "Reseña agregada al Learning Path: " + selectedLP.getTitulo());
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Por favor selecciona un Learning Path y escribe una reseña.");
            }
        });

        panel.add(lpComboBox, BorderLayout.NORTH);
        panel.add(new JScrollPane(reseñaArea), BorderLayout.CENTER);
        panel.add(darReseñaBtn, BorderLayout.SOUTH);

        add(panel);
    }
}

