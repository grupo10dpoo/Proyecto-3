package Proyecto1.GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import Proyecto1.ProfesorCalificador; // Clase lógica
import Proyecto1.Main; // Acceso a datos compartidos
import Proyecto1.Profesor;

public class CrearProfesorGUI extends JFrame {
    public CrearProfesorGUI() {
        setTitle("Crear Profesor");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 2, 10, 10));

        // Campos de entrada
        JTextField nombreField = new JTextField();
        JPasswordField contrasenaField = new JPasswordField();
        JTextField correoField = new JTextField();

        // Botón de registro
        JButton crearBtn = new JButton("Crear Profesor");
        crearBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombre = nombreField.getText();
                String contrasena = new String(contrasenaField.getPassword());
                String correo = correoField.getText();

                if (nombre.isEmpty() || contrasena.isEmpty() || correo.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Por favor, completa todos los campos.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Crear el profesor calificador y añadirlo a la lista
                Profesor profesor = new Profesor(nombre, contrasena, correo, Main.profesoresCalificador.size() + 1);
                Main.profesores.add(profesor);
                JOptionPane.showMessageDialog(null, "Profesor Calificador creado exitosamente.");
                dispose();
            }
        });

        // Añadir componentes al panel
        panel.add(new JLabel("Nombre de Usuario:"));
        panel.add(nombreField);
        panel.add(new JLabel("Contraseña:"));
        panel.add(contrasenaField);
        panel.add(new JLabel("Correo:"));
        panel.add(correoField);
        panel.add(new JLabel());
        panel.add(crearBtn);

        add(panel);
    }
}

