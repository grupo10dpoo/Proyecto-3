package Proyecto1.GUI;

import Proyecto1.LearningPath;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;

public class ModificarLearningPathGUI extends JFrame {
    private List<LearningPath> learningPaths; // Lista de Learning Paths compartida
    private JComboBox<LearningPath> learningPathComboBox;
    private JTextField tituloField;
    private JTextField descripcionField;
    private JTextField tipoField;
    private JTextField objetivoField;
    private JTextField nivelDificultadField;
    private JTextField tiempoEstimadoField;

    public ModificarLearningPathGUI(List<LearningPath> learningPaths) {
        this.learningPaths = learningPaths; // Asignar la lista recibida

        setTitle("Modificar Learning Path");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(7, 2, 10, 10));

        // Dropdown para seleccionar el Learning Path
        inputPanel.add(new JLabel("Seleccionar Learning Path:"));
        learningPathComboBox = new JComboBox<>(learningPaths.toArray(new LearningPath[0]));
        learningPathComboBox.addActionListener(e -> cargarDatosLearningPath());
        inputPanel.add(learningPathComboBox);

        // Campos para modificar los atributos
        tituloField = new JTextField();
        descripcionField = new JTextField();
        tipoField = new JTextField();
        objetivoField = new JTextField();
        nivelDificultadField = new JTextField();
        tiempoEstimadoField = new JTextField();

        inputPanel.add(new JLabel("Título:"));
        inputPanel.add(tituloField);

        inputPanel.add(new JLabel("Descripción:"));
        inputPanel.add(descripcionField);

        inputPanel.add(new JLabel("Tipo:"));
        inputPanel.add(tipoField);

        inputPanel.add(new JLabel("Objetivo:"));
        inputPanel.add(objetivoField);

        inputPanel.add(new JLabel("Nivel de Dificultad:"));
        inputPanel.add(nivelDificultadField);

        inputPanel.add(new JLabel("Tiempo Estimado (horas):"));
        inputPanel.add(tiempoEstimadoField);

        // Botón para guardar cambios
        JButton guardarButton = new JButton("Guardar Cambios");
        guardarButton.addActionListener((ActionEvent e) -> guardarCambios());

        add(inputPanel, BorderLayout.CENTER);
        add(guardarButton, BorderLayout.SOUTH);
    }

    /**
     * Carga los datos del Learning Path seleccionado en los campos de texto.
     */
    private void cargarDatosLearningPath() {
        LearningPath selectedLP = (LearningPath) learningPathComboBox.getSelectedItem();
        if (selectedLP != null) {
            tituloField.setText(selectedLP.getTitulo());
            descripcionField.setText(selectedLP.getDescripcion());
            tipoField.setText(selectedLP.getTipo());
            objetivoField.setText(selectedLP.getObjetivo());
            nivelDificultadField.setText(selectedLP.getNivelDificultad());
            tiempoEstimadoField.setText(String.valueOf(selectedLP.getTiempoEstimado()));
        }
    }

    /**
     * Guarda los cambios realizados en el Learning Path seleccionado.
     */
    private void guardarCambios() {
        LearningPath selectedLP = (LearningPath) learningPathComboBox.getSelectedItem();
        if (selectedLP != null) {
            try {
                selectedLP.setTitulo(tituloField.getText());
                selectedLP.setDescripcion(descripcionField.getText());
                selectedLP.setTipo(tipoField.getText());
                selectedLP.setObjetivo(objetivoField.getText());
                selectedLP.setNivelDificultad(nivelDificultadField.getText());
                selectedLP.setTiempoEstimado(Double.parseDouble(tiempoEstimadoField.getText()));

                JOptionPane.showMessageDialog(this, "Learning Path modificado con éxito.");
                dispose();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Por favor, ingresa un valor válido para el tiempo estimado.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "No se seleccionó ningún Learning Path.");
        }
    }
}
