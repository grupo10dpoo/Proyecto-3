package Proyecto1.GUI;

import Proyecto1.LearningPath;
import Proyecto1.Estudiante;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.stream.Collectors;

public class MenuEstudianteGUI extends JFrame {
    public MenuEstudianteGUI(Estudiante estudiante, List<LearningPath> learningPaths) {
        setTitle("Menú del Estudiante");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 1, 10, 10));

        JLabel welcomeLabel = new JLabel("Bienvenido " + estudiante.getNombreUsuario(), SwingConstants.CENTER);
        panel.add(welcomeLabel);

        // Botón para inscribirse a un Learning Path
        JButton inscribirseBtn = new JButton("Inscribirse a un Learning Path");
        inscribirseBtn.addActionListener(e -> new InscribirseLearningPathGUI(estudiante, learningPaths).setVisible(true));

        // Botón para dar reseña sobre un Learning Path
        JButton darReseñaBtn = new JButton("Dar Reseña sobre un Learning Path");
        darReseñaBtn.addActionListener(e -> new DarReseñaGUI(estudiante, learningPaths).setVisible(true));

        // Botón para ver y marcar actividades como completadas
        JButton completarActividadBtn = new JButton("Ver y Completar Actividades");
        completarActividadBtn.addActionListener(e -> new VerActividadesGUI(estudiante, learningPaths).setVisible(true));

        // Botón para ver Learning Paths recomendados
        JButton recomendadosBtn = new JButton("Learning Paths Recomendados");
        recomendadosBtn.addActionListener(e -> new LearningPathsRecomendadosGUI(estudiante, learningPaths).setVisible(true));
        JButton verProgresoBtn = new JButton("Ver Progreso");
        verProgresoBtn.addActionListener(e -> {
            // Crear y mostrar la interfaz de progreso
            new VerProgresoGUI(estudiante, learningPaths).setVisible(true);
        });
        // Añadir los botones al panel
        panel.add(inscribirseBtn);
        panel.add(darReseñaBtn);
        panel.add(completarActividadBtn);
        panel.add(recomendadosBtn);
        panel.add(verProgresoBtn);
        
        add(panel);
    }
}


