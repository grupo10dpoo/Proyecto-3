package Proyecto1.GUI;

import javax.swing.*;
import java.awt.*;
import Proyecto1.Profesor;
import Proyecto1.LearningPath;
import Proyecto1.Profesor;
import java.util.List;
public class MenuProfesorGUI extends JFrame {
    public MenuProfesorGUI(Profesor profesor,List<LearningPath> learningPaths) {
        setTitle("Menú del Profesor");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 1, 10, 10));

        JLabel welcomeLabel = new JLabel("Bienvenido" + profesor.getNombreUsuario(), SwingConstants.CENTER);
        panel.add(welcomeLabel);

        // Botón para Crear Learning Path
        JButton crearLPBtn = new JButton("Crear Learning Path");
        crearLPBtn.addActionListener(e -> new CrearLearningPathGUI(learningPaths).setVisible(true));

        // Botón para Modificar Learning Path
        JButton modificarLPBtn = new JButton("Modificar Learning Path");
        modificarLPBtn.addActionListener(e -> new ModificarLearningPathGUI(learningPaths).setVisible(true));

        // Botón para Agregar Actividad
        JButton agregarActividadBtn = new JButton("Agregar Actividad");
        agregarActividadBtn.addActionListener(e -> new AgregarActividadGUI(learningPaths).setVisible(true));

        // Botón para Ver Learning Path y Reseñas
        JButton verLPyReseñasBtn = new JButton("Ver Learning Path y Reseñas");
        verLPyReseñasBtn.addActionListener(e -> new VerLearningPathsGUI(learningPaths).setVisible(true));

        // Botón para Cerrar Sesión
        JButton cerrarSesionBtn = new JButton("Cerrar Sesión");
        cerrarSesionBtn.addActionListener(e -> dispose());

        // Añadir los botones al panel
        panel.add(crearLPBtn);
        panel.add(modificarLPBtn);
        panel.add(agregarActividadBtn);
        panel.add(verLPyReseñasBtn);
        panel.add(cerrarSesionBtn);

        add(panel);
    }
}


