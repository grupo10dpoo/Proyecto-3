package Proyecto1.GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import Proyecto1.LearningPath;
import java.util.List;

public class CrearLearningPathGUI extends JFrame {
    private List<LearningPath> learningPaths; // Lista de LearningPaths

    public CrearLearningPathGUI(List<LearningPath> learningPaths) {
        this.learningPaths = learningPaths; // Asignar la lista recibida
        setTitle("Crear Learning Path");
        setSize(400, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(8, 2, 10, 10));

        // Componentes de entrada para los atributos del Learning Path
        JTextField idField = new JTextField();
        JTextField tituloField = new JTextField();
        JTextField descripcionField = new JTextField();
        JTextField tipoField = new JTextField();
        JTextField objetivoField = new JTextField();
        JTextField nivelDificultadField = new JTextField();
        JTextField tiempoEstimadoField = new JTextField();

        panel.add(new JLabel("ID:"));
        panel.add(idField);

        panel.add(new JLabel("Título:"));
        panel.add(tituloField);

        panel.add(new JLabel("Descripción:"));
        panel.add(descripcionField);

        panel.add(new JLabel("Tipo:"));
        panel.add(tipoField);

        panel.add(new JLabel("Objetivo:"));
        panel.add(objetivoField);

        panel.add(new JLabel("Nivel de Dificultad:"));
        panel.add(nivelDificultadField);

        panel.add(new JLabel("Tiempo Estimado (horas):"));
        panel.add(tiempoEstimadoField);

        JButton crearBtn = new JButton("Crear");
        crearBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int id = Integer.parseInt(idField.getText());
                    String titulo = tituloField.getText();
                    String descripcion = descripcionField.getText();
                    String tipo = tipoField.getText();
                    String objetivo = objetivoField.getText();
                    String nivelDificultad = nivelDificultadField.getText();
                    double tiempoEstimado = Double.parseDouble(tiempoEstimadoField.getText());

                    // Crear un nuevo Learning Path
                    LearningPath nuevoLP = new LearningPath(id, titulo, descripcion, tipo, objetivo, nivelDificultad, tiempoEstimado);
                    learningPaths.add(nuevoLP); // Agregar el nuevo Learning Path a la lista

                    JOptionPane.showMessageDialog(null, "Learning Path creado exitosamente:\n" + nuevoLP.getTitulo());

                    // Redirigir a la interfaz de lista de Learning Paths
                    // Aquí podrías abrir una nueva ventana que muestre los Learning Paths existentes
                    new VerLearningPathsGUI(learningPaths).setVisible(true);
                    dispose();
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Por favor, ingrese valores válidos.");
                }
            }
        });

        panel.add(crearBtn);
        add(panel);
    }
}



