package Proyecto1.GUI;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import Proyecto1.Estudiante;
import Proyecto1.LearningPath;

public class VerProgresoGUI extends JFrame {

    public VerProgresoGUI(Estudiante estudiante, List<LearningPath> learningPaths) {
        setTitle("Ver Progreso");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        // Lista para seleccionar el LearningPath
        DefaultListModel<String> listModel = new DefaultListModel<>();
        for (LearningPath lp : estudiante.getLearningPathsInscritos()) {
            listModel.addElement(lp.getTitulo() + " (ID: " + lp.getId() + ")");
        }

        JList<String> lpList = new JList<>(listModel);
        JScrollPane scrollPane = new JScrollPane(lpList);
        panel.add(scrollPane, BorderLayout.CENTER);

        JButton calcularProgresoBtn = new JButton("Calcular Progreso");
        calcularProgresoBtn.addActionListener(e -> {
            int selectedIndex = lpList.getSelectedIndex();
            if (selectedIndex != -1) {
                LearningPath selectedLP = estudiante.getLearningPathsInscritos().get(selectedIndex);
                double progreso = calcularProgreso(selectedLP, estudiante);

                // Mostrar barra de progreso
                JProgressBar progressBar = new JProgressBar(0, 100);
                progressBar.setValue((int) progreso);
                progressBar.setStringPainted(true);

                JOptionPane.showMessageDialog(this, progressBar, 
                        "Progreso en " + selectedLP.getTitulo(), JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Por favor, seleccione un Learning Path.", 
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        panel.add(calcularProgresoBtn, BorderLayout.SOUTH);
        add(panel);
    }

    private double calcularProgreso(LearningPath lp, Estudiante estudiante) {
        int totalActividades = lp.getActividades().size();
        int completadas = (int) lp.getActividadesCompletadas(estudiante).stream().count();

        if (totalActividades == 0) return 0;
        return (completadas / (double) totalActividades) * 100;
    }
}

