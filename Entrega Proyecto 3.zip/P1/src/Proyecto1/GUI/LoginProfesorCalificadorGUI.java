package Proyecto1.GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import Proyecto1.ProfesorCalificador; // Clase lógica
import Proyecto1.Actividad;
import Proyecto1.Main; // Acceso a datos compartidos
import java.util.List;
public class LoginProfesorCalificadorGUI extends JFrame {
    public LoginProfesorCalificadorGUI(List<ProfesorCalificador> profesoresCalificador,List<Actividad> actividades) {
        setTitle("Inicio de Sesión - Profesor Calificador");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 2, 10, 10));

        // Campos de credenciales
        JTextField nombreField = new JTextField();
        JPasswordField contrasenaField = new JPasswordField();

        // Botón para iniciar sesión
        JButton loginBtn = new JButton("Iniciar Sesión");
        loginBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombre = nombreField.getText();
                String contrasena = new String(contrasenaField.getPassword());

                // Validación de credenciales
                ProfesorCalificador profesorCalificador = Main.buscarProfesorCalificador(nombre, contrasena);
                if (profesorCalificador != null) {
                    JOptionPane.showMessageDialog(null, "Inicio de sesión exitoso.");
                    new MenuProfesorCalificadorGUI(profesorCalificador,actividades).setVisible(true);
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Credenciales incorrectas.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Añadir componentes al panel
        panel.add(new JLabel("Nombre de Usuario:"));
        panel.add(nombreField);
        panel.add(new JLabel("Contraseña:"));
        panel.add(contrasenaField);
        panel.add(new JLabel());
        panel.add(loginBtn);

        add(panel);
    }
}

