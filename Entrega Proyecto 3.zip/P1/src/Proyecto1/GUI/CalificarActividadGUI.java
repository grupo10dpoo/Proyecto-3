package Proyecto1.GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import Proyecto1.Actividad;
import Proyecto1.ProfesorCalificador;

public class CalificarActividadGUI extends JFrame {
    public CalificarActividadGUI(ProfesorCalificador profesor, List<Actividad> actividades) {
        setTitle("Calificar Actividades");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout());
        JLabel titleLabel = new JLabel("Selecciona una actividad para calificar", SwingConstants.CENTER);
        mainPanel.add(titleLabel, BorderLayout.NORTH);

        DefaultListModel<Actividad> model = new DefaultListModel<>();
        for (Actividad actividad : actividades) {
            if (!actividad.getEstudiantesCompletaron().isEmpty()) {
                model.addElement(actividad);
            }
        }

        JList<Actividad> actividadList = new JList<>(model);
        actividadList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollPane = new JScrollPane(actividadList);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new GridLayout(2, 1, 5, 5));
        JTextField calificacionField = new JTextField();
        JTextArea retroalimentacionArea = new JTextArea(3, 20);
        retroalimentacionArea.setLineWrap(true);
        retroalimentacionArea.setWrapStyleWord(true);

        bottomPanel.add(new JLabel("Calificación (1-5):"));
        bottomPanel.add(calificacionField);
        bottomPanel.add(new JLabel("Retroalimentación:"));
        bottomPanel.add(new JScrollPane(retroalimentacionArea));

        JButton calificarButton = new JButton("Calificar");
        calificarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Actividad actividadSeleccionada = actividadList.getSelectedValue();
                if (actividadSeleccionada != null) {
                    try {
                        int calificacion = Integer.parseInt(calificacionField.getText());
                        if (calificacion < 1 || calificacion > 5) {
                            throw new NumberFormatException();
                        }
                        String retroalimentacion = retroalimentacionArea.getText();
                        actividadSeleccionada.calificar(calificacion, retroalimentacion);
                        JOptionPane.showMessageDialog(CalificarActividadGUI.this, 
                                "Actividad calificada exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                        dispose();
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(CalificarActividadGUI.this, 
                                "Por favor ingresa una calificación válida entre 1 y 5.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(CalificarActividadGUI.this, 
                            "Selecciona una actividad antes de calificar.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        mainPanel.add(bottomPanel, BorderLayout.SOUTH);
        mainPanel.add(calificarButton, BorderLayout.SOUTH);

        add(mainPanel);
        setVisible(true);
    }
}

