package Proyecto1.GUI;

import Proyecto1.LearningPath;
import Proyecto1.Actividad;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;

public class AgregarActividadGUI extends JFrame {
    private List<LearningPath> learningPaths; // Lista de Learning Paths compartida
    private JComboBox<LearningPath> learningPathComboBox;
    private JTextField nombreField;
    private JTextField tipoField;
    private JTextField idField;
    private JTextField descripcionField;
    private JTextField objetivoField;
    private JTextField nivelDificultadField;
    private JTextField duracionField;
    private JTextField fechaEntregaField;

    public AgregarActividadGUI(List<LearningPath> learningPaths) {
        this.learningPaths = learningPaths;

        setTitle("Agregar Actividad a Learning Path");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Panel para seleccionar el Learning Path
        JPanel selectionPanel = new JPanel(new GridLayout(1, 2, 10, 10));
        selectionPanel.add(new JLabel("Seleccionar Learning Path:"));
        learningPathComboBox = new JComboBox<>(learningPaths.toArray(new LearningPath[0]));
        selectionPanel.add(learningPathComboBox);

        // Panel para ingresar los datos de la actividad
        JPanel inputPanel = new JPanel(new GridLayout(8, 2, 10, 10));
        nombreField = new JTextField();
        tipoField = new JTextField();
        idField = new JTextField();
        descripcionField = new JTextField();
        objetivoField = new JTextField();
        nivelDificultadField = new JTextField();
        duracionField = new JTextField();
        fechaEntregaField = new JTextField();

        inputPanel.add(new JLabel("Nombre:"));
        inputPanel.add(nombreField);

        inputPanel.add(new JLabel("Tipo:"));
        inputPanel.add(tipoField);

        inputPanel.add(new JLabel("ID:"));
        inputPanel.add(idField);

        inputPanel.add(new JLabel("Descripción:"));
        inputPanel.add(descripcionField);

        inputPanel.add(new JLabel("Objetivo:"));
        inputPanel.add(objetivoField);

        inputPanel.add(new JLabel("Nivel de Dificultad:"));
        inputPanel.add(nivelDificultadField);

        inputPanel.add(new JLabel("Duración (horas):"));
        inputPanel.add(duracionField);

        inputPanel.add(new JLabel("Fecha de Entrega (dd/mm/yyyy):"));
        inputPanel.add(fechaEntregaField);

        // Botón para agregar la actividad
        JButton agregarBtn = new JButton("Agregar Actividad");
        agregarBtn.addActionListener(this::agregarActividad);

        // Layout principal
        add(selectionPanel, BorderLayout.NORTH);
        add(inputPanel, BorderLayout.CENTER);
        add(agregarBtn, BorderLayout.SOUTH);
    }

    /**
     * Método para agregar una actividad al Learning Path seleccionado.
     */
    private void agregarActividad(ActionEvent e) {
        LearningPath selectedLP = (LearningPath) learningPathComboBox.getSelectedItem();

        if (selectedLP != null) {
            try {
                String nombre = nombreField.getText();
                String tipo = tipoField.getText();
                int id = Integer.parseInt(idField.getText());
                String descripcion = descripcionField.getText();
                String objetivo = objetivoField.getText();
                String nivelDificultad = nivelDificultadField.getText();
                int duracion = Integer.parseInt(duracionField.getText());
                String fechaEntrega = fechaEntregaField.getText();

                // Crear la actividad
                Actividad nuevaActividad = new Actividad(
                        nombre,
                        tipo,
                        id,
                        descripcion,
                        objetivo,
                        nivelDificultad,
                        duracion,
                        fechaEntrega
                );

                // Agregar la actividad al Learning Path
                selectedLP.agregarActividad(nuevaActividad);

                JOptionPane.showMessageDialog(this, "Actividad agregada exitosamente al Learning Path: " + selectedLP.getTitulo());
                dispose();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Por favor, ingresa valores válidos en los campos numéricos.");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error al agregar actividad: " + ex.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(this, "Por favor, selecciona un Learning Path.");
        }
    }
}
