package Proyecto1.GUI;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import Proyecto1.Actividad;

public class TasaExitoGUI extends JFrame {
    public TasaExitoGUI(List<Actividad> actividades) {
        setTitle("Tasa de Éxito y Tiempo Promedio");
        setSize(500, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout());
        JLabel titleLabel = new JLabel("Tasa de Éxito y Tiempo Promedio por Actividad", SwingConstants.CENTER);
        mainPanel.add(titleLabel, BorderLayout.NORTH);

        DefaultListModel<String> model = new DefaultListModel<>();
        for (Actividad actividad : actividades) {
            int exitosas = (int) actividad.getNotas().stream().filter(nota -> nota >= 3).count();
            int totalEstudiantes = actividad.getEstudiantesCompletaron().size();
            double tasaExito = (totalEstudiantes > 0) ? (exitosas * 100.0 / totalEstudiantes) : 0.0;
            double tiempoPromedio = actividad.getDuracion() * totalEstudiantes;

            model.addElement(String.format("Actividad: %s | Tasa de Éxito: %.2f%% | Tiempo Promedio: %.2f horas", 
                    actividad.getNombre(), tasaExito, tiempoPromedio));
        }

        JList<String> resultList = new JList<>(model);
        resultList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollPane = new JScrollPane(resultList);

        mainPanel.add(scrollPane, BorderLayout.CENTER);
        add(mainPanel);

        setVisible(true);
    }
}

