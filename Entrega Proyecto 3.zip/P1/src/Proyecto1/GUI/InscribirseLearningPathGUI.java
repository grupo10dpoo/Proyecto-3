package Proyecto1.GUI;

import Proyecto1.Estudiante;
import Proyecto1.LearningPath;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;

public class InscribirseLearningPathGUI extends JFrame {
    public InscribirseLearningPathGUI(Estudiante estudiante, List<LearningPath> learningPaths) {
        setTitle("Inscribirse a un Learning Path");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout());

        DefaultListModel<String> listModel = new DefaultListModel<>();
        for (LearningPath lp : learningPaths) {
            listModel.addElement("Titulo: "+lp.getTitulo() + " | ID: " + lp.getId()+" | Descripcion: "+lp.getDescripcion()+" | Tipo: "+lp.getTipo()+" | Objetivo: "+lp.getObjetivo()+" | Dificultad: "+lp.getNivelDificultad()+" | Tiempo Estimado: "+lp.getTiempoEstimado()+ " | ");
        }

        JList<String> lpList = new JList<>(listModel);
        panel.add(new JScrollPane(lpList), BorderLayout.CENTER);

        JButton inscribirseBtn = new JButton("Inscribirse");
        inscribirseBtn.addActionListener((ActionEvent e) -> {
            int selectedIndex = lpList.getSelectedIndex();
            if (selectedIndex != -1) {
                LearningPath selectedLP = learningPaths.get(selectedIndex);
                estudiante.inscribirseEnLearningPath(selectedLP);
                JOptionPane.showMessageDialog(this, "Te has inscrito al Learning Path: " + selectedLP.getTitulo());
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Por favor selecciona un Learning Path.");
            }
        });

        panel.add(inscribirseBtn, BorderLayout.SOUTH);
        add(panel);
    }
}

