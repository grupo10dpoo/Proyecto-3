package Proyecto1;

public class Examen {

}
